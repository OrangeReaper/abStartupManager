#!/bin/bash
sudo iptables-restore < /opt/cleariptables.conf



